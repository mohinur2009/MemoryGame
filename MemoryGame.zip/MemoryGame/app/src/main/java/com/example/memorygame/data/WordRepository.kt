package com.example.memorygame.data

import android.annotation.SuppressLint
import android.content.Context
import com.example.memorygame.model.BoardTheme
import com.example.memorygame.model.WordItem
import com.example.memorygame.model.WordList
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader

class WordRepository(private val context: Context) {

    fun loadWordLists(): List<WordList> {
        val result = ArrayList<WordList>()
        val jsonText = readAssetText("word_lists.json")
        if (jsonText.isEmpty()) {
            return result
        }
        try {
            val root = JSONObject(jsonText)
            val listsArray = root.getJSONArray("wordLists")
            for (listIndex in 0 until listsArray.length()) {
                val listObject = listsArray.getJSONObject(listIndex)
                val itemsArray = listObject.getJSONArray("items")
                val items = ArrayList<WordItem>()
                for (itemIndex in 0 until itemsArray.length()) {
                    val itemObject = itemsArray.getJSONObject(itemIndex)
                    val item = WordItem(
                        id = itemObject.getString("id"),
                        word = itemObject.getString("word"),
                        imageName = itemObject.optString("image", ""),
                        emoji = itemObject.optString("emoji", "")
                    )
                    items.add(item)
                }
                val wordList = WordList(
                    id = listObject.getString("id"),
                    title = listObject.getString("title"),
                    iconEmoji = listObject.optString("icon", "🃏"),
                    theme = parseTheme(listObject.optString("theme", "SEA")),
                    hasPictures = listObject.optBoolean("hasPictures", true),
                    items = items
                )
                result.add(wordList)
            }
        } catch (exception: JSONException) {
            result.clear()
        }
        return result
    }

    private fun parseTheme(value: String): BoardTheme {
        for (theme in BoardTheme.values()) {
            if (theme.name.equals(value, ignoreCase = true)) {
                return theme
            }
        }
        return BoardTheme.SEA
    }

    private fun readAssetText(fileName: String): String {
        try {
            val inputStream = context.assets.open(fileName)
            val reader = BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8))
            val builder = StringBuilder()
            var line = reader.readLine()
            while (line != null) {
                builder.append(line)
                builder.append("\n")
                line = reader.readLine()
            }
            reader.close()
            return builder.toString()
        } catch (exception: IOException) {
            return ""
        }
    }
}

object ResourceHelper {

    @SuppressLint("DiscouragedApi")
    fun findDrawableId(context: Context, name: String): Int {
        if (name.isEmpty()) {
            return 0
        }
        return context.resources.getIdentifier(name, "drawable", context.packageName)
    }
}