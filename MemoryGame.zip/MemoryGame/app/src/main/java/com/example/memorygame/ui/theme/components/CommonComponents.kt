package com.example.memorygame.ui.theme.components

    import androidx.compose.animation.core.Animatable
    import androidx.compose.animation.core.FastOutSlowInEasing
    import androidx.compose.animation.core.LinearEasing
    import androidx.compose.animation.core.RepeatMode
    import androidx.compose.animation.core.animateFloat
    import androidx.compose.animation.core.infiniteRepeatable
    import androidx.compose.animation.core.rememberInfiniteTransition
    import androidx.compose.animation.core.tween
    import androidx.compose.foundation.Canvas
    import androidx.compose.foundation.Image
    import androidx.compose.foundation.background
    import androidx.compose.foundation.clickable
    import androidx.compose.foundation.layout.Arrangement
    import androidx.compose.foundation.layout.Box
    import androidx.compose.foundation.layout.BoxScope
    import androidx.compose.foundation.layout.Row
    import androidx.compose.foundation.layout.fillMaxSize
    import androidx.compose.foundation.layout.fillMaxWidth
    import androidx.compose.foundation.layout.padding
    import androidx.compose.foundation.layout.size
    import androidx.compose.foundation.shape.RoundedCornerShape
    import androidx.compose.material3.Text
    import androidx.compose.runtime.Composable
    import androidx.compose.runtime.LaunchedEffect
    import androidx.compose.runtime.remember
    import androidx.compose.ui.Alignment
    import androidx.compose.ui.Modifier
    import androidx.compose.ui.draw.clip
    import androidx.compose.ui.draw.shadow
    import androidx.compose.ui.geometry.Offset
    import androidx.compose.ui.geometry.Size
    import androidx.compose.ui.graphics.Brush
    import androidx.compose.ui.graphics.Color
    import androidx.compose.ui.graphics.Shadow
    import androidx.compose.ui.graphics.TransformOrigin
    import androidx.compose.ui.graphics.drawscope.Stroke
    import androidx.compose.ui.graphics.drawscope.rotate
    import androidx.compose.ui.graphics.graphicsLayer
    import androidx.compose.ui.layout.ContentScale
    import androidx.compose.ui.platform.LocalContext
    import androidx.compose.ui.platform.LocalDensity
    import androidx.compose.ui.res.painterResource
    import androidx.compose.ui.text.TextStyle
    import androidx.compose.ui.text.font.FontWeight
    import androidx.compose.ui.unit.Dp
    import androidx.compose.ui.unit.dp
    import androidx.compose.ui.unit.sp
    import com.example.memorygame.data.ResourceHelper
    import com.example.memorygame.model.BoardTheme
    import com.example.memorygame.model.WordItem
    import com.example.memorygame.ui.theme.Palettes
    import com.example.memorygame.ui.theme.ThemePalette
    import kotlin.math.cos
    import kotlin.math.floor
    import kotlin.math.sin
    import kotlin.random.Random

    data class ParticleSpec(
        val startX: Float,
        val startY: Float,
        val radius: Float,
        val speed: Float,
        val phase: Float,
        val alpha: Float
    )

    data class ConfettiPiece(
        val angle: Float,
        val distance: Float,
        val pieceSize: Float,
        val color: Color,
        val spin: Float
    )

    val confettiColors: List<Color> = listOf(
        Color(0xFFFF5252),
        Color(0xFFFFD740),
        Color(0xFF69F0AE),
        Color(0xFF40C4FF),
        Color(0xFFFF4081),
        Color(0xFFB388FF),
        Color(0xFFFFAB40)
    )

    val softTextShadow: TextStyle = TextStyle(
        shadow = Shadow(color = Color(0x66000000), offset = Offset(3f, 3f), blurRadius = 6f)
    )

    fun createParticles(count: Int, seed: Int): List<ParticleSpec> {
        val random = Random(seed)
        val particles = ArrayList<ParticleSpec>()
        for (index in 0 until count) {
            val particle = ParticleSpec(
                startX = random.nextFloat(),
                startY = random.nextFloat(),
                radius = 6f + random.nextFloat() * 18f,
                speed = (1 + random.nextInt(3)).toFloat(),
                phase = random.nextFloat() * 6.2832f,
                alpha = 0.3f + random.nextFloat() * 0.4f
            )
            particles.add(particle)
        }
        return particles
    }

    fun createConfettiPieces(seed: Int): List<ConfettiPiece> {
        val random = Random(seed)
        val pieces = ArrayList<ConfettiPiece>()
        for (index in 0 until 70) {
            val piece = ConfettiPiece(
                angle = random.nextFloat() * 6.2832f,
                distance = 0.2f + random.nextFloat() * 0.5f,
                pieceSize = 14f + random.nextFloat() * 16f,
                color = confettiColors[index % confettiColors.size],
                spin = 1f + random.nextFloat() * 3f
            )
            pieces.add(piece)
        }
        return pieces
    }

    fun fractionalPart(value: Float): Float {
        return value - floor(value)
    }

    @Composable
    fun ThemedBackground(theme: BoardTheme, content: @Composable BoxScope.() -> Unit) {
        val palette = Palettes.forTheme(theme)
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.verticalGradient(colors = listOf(palette.skyTop, palette.skyBottom)))
        ) {
            FloatingParticles(theme = theme)
            BottomDecoration(palette = palette, modifier = Modifier.align(Alignment.BottomCenter))
            content()
        }
    }

    @Composable
    fun FloatingParticles(theme: BoardTheme) {
        val particles = remember(theme) { createParticles(count = 26, seed = theme.ordinal + 7) }
        val transition = rememberInfiniteTransition(label = "particles")
        val progress = transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 14000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "particleProgress"
        )
        Canvas(modifier = Modifier.fillMaxSize()) {
            for (particle in particles) {
                val travelled = fractionalPart(particle.startY + progress.value * particle.speed)
                var y = (1f - travelled) * size.height
                if (theme == BoardTheme.WINTER) {
                    y = travelled * size.height
                }
                val wobble = sin(progress.value * 6.2832f * particle.speed + particle.phase) * 14f
                val x = particle.startX * size.width + wobble
                val center = Offset(x, y)
                if (theme == BoardTheme.SEA) {
                    drawCircle(
                        color = Color.White.copy(alpha = particle.alpha + 0.2f),
                        radius = particle.radius,
                        center = center,
                        style = Stroke(width = 3f)
                    )
                    drawCircle(
                        color = Color.White.copy(alpha = particle.alpha),
                        radius = particle.radius * 0.25f,
                        center = Offset(x - particle.radius * 0.35f, y - particle.radius * 0.35f)
                    )
                } else if (theme == BoardTheme.WINTER) {
                    drawCircle(
                        color = Color.White.copy(alpha = particle.alpha + 0.3f),
                        radius = particle.radius * 0.5f,
                        center = center
                    )
                } else {
                    drawCircle(
                        color = Color.White.copy(alpha = particle.alpha * 0.6f),
                        radius = particle.radius * 0.6f,
                        center = center
                    )
                }
            }
        }
    }

    @Composable
    fun BottomDecoration(palette: ThemePalette, modifier: Modifier) {
        val transition = rememberInfiniteTransition(label = "sway")
        val sway = transition.animateFloat(
            initialValue = -8f,
            targetValue = 8f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 1400),
                repeatMode = RepeatMode.Reverse
            ),
            label = "swayAngle"
        )
        Row(
            modifier = modifier
                .fillMaxWidth()
                .padding(bottom = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            for (index in 0 until palette.decorationEmojis.size) {
                val emoji = palette.decorationEmojis[index]
                var direction = 1f
                if (index % 2 == 1) {
                    direction = -1f
                }
                val angle = sway.value * direction
                Text(
                    text = emoji,
                    fontSize = 28.sp,
                    modifier = Modifier.graphicsLayer {
                        rotationZ = angle
                        transformOrigin = TransformOrigin(0.5f, 1f)
                    }
                )
            }
        }
    }

    @Composable
    fun CardPicture(item: WordItem, pictureSize: Dp, modifier: Modifier) {
        val context = LocalContext.current
        val drawableId = remember(item.imageName) { ResourceHelper.findDrawableId(context, item.imageName) }
        if (drawableId != 0) {
            Image(
                painter = painterResource(id = drawableId),
                contentDescription = item.word,
                modifier = modifier,
                contentScale = ContentScale.Fit
            )
        } else {
            val emojiSize = with(LocalDensity.current) { (pictureSize * 0.5f).toSp() }
            Box(modifier = modifier, contentAlignment = Alignment.Center) {
                Text(text = item.emoji, fontSize = emojiSize)
            }
        }
    }

    @Composable
    fun MascotView(imageName: String, emoji: String, mascotSize: Dp) {
        val context = LocalContext.current
        val drawableId = remember(imageName) { ResourceHelper.findDrawableId(context, imageName) }
        if (drawableId != 0) {
            Image(
                painter = painterResource(id = drawableId),
                contentDescription = "mascot",
                modifier = Modifier.size(mascotSize),
                contentScale = ContentScale.Fit
            )
        } else {
            val emojiSize = with(LocalDensity.current) { (mascotSize * 0.72f).toSp() }
            Box(modifier = Modifier.size(mascotSize), contentAlignment = Alignment.Center) {
                Text(text = emoji, fontSize = emojiSize)
            }
        }
    }

    @Composable
    fun PillButton(text: String, background: Color, textColor: Color, onClick: () -> Unit) {
        Box(
            modifier = Modifier
                .shadow(elevation = 4.dp, shape = RoundedCornerShape(50))
                .clip(RoundedCornerShape(50))
                .background(background)
                .clickable { onClick() }
                .padding(horizontal = 16.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(text = text, color = textColor, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        }
    }

    @Composable
    fun InfoChip(text: String, textColor: Color) {
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(Color.White.copy(alpha = 0.88f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(text = text, color = textColor, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }

    @Composable
    fun ConfettiBurst(burstId: Int, message: String) {
        val pieces = remember(burstId) { createConfettiPieces(seed = burstId) }
        val progress = remember(burstId) { Animatable(0f) }
        LaunchedEffect(burstId) {
            progress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing)
            )
        }
        val current = progress.value
        if (current < 1f) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val centerX = size.width / 2f
                    val centerY = size.height / 2f
                    for (piece in pieces) {
                        val travel = piece.distance * size.minDimension * current
                        val x = centerX + cos(piece.angle) * travel
                        val y = centerY + sin(piece.angle) * travel + 260f * current * current
                        val fadedColor = piece.color.copy(alpha = 1f - current)
                        rotate(degrees = piece.spin * current * 360f, pivot = Offset(x, y)) {
                            drawRect(
                                color = fadedColor,
                                topLeft = Offset(x - piece.pieceSize / 2f, y - piece.pieceSize / 4f),
                                size = Size(piece.pieceSize, piece.pieceSize / 2f)
                            )
                        }
                    }
                }
                var growth = current * 4f
                if (growth > 1f) {
                    growth = 1f
                }
                val textScale = 0.4f + growth * 0.8f
                val textAlpha = 1f - current * current
                Text(
                    text = message,
                    fontSize = 46.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    style = softTextShadow,
                    modifier = Modifier.graphicsLayer {
                        scaleX = textScale
                        scaleY = textScale
                        alpha = textAlpha
                    }
                )
            }
        }
    }

    @Composable
    fun ConfettiRain() {
        val pieces = remember { createParticles(count = 60, seed = 99) }
        val transition = rememberInfiniteTransition(label = "confettiRain")
        val progress = transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(durationMillis = 7000, easing = LinearEasing),
                repeatMode = RepeatMode.Restart
            ),
            label = "rainProgress"
        )
        Canvas(modifier = Modifier.fillMaxSize()) {
            for (index in 0 until pieces.size) {
                val piece = pieces[index]
                val travelled = fractionalPart(piece.startY + progress.value * piece.speed)
                val y = travelled * size.height
                val x = piece.startX * size.width + sin(progress.value * 6.2832f * piece.speed + piece.phase) * 30f
                val color = confettiColors[index % confettiColors.size]
                val angle = progress.value * 360f * piece.speed + piece.phase * 57f
                val pieceWidth = piece.radius + 8f
                rotate(degrees = angle, pivot = Offset(x, y)) {
                    drawRect(
                        color = color,
                        topLeft = Offset(x - pieceWidth / 2f, y - pieceWidth / 4f),
                        size = Size(pieceWidth, pieceWidth / 2f)
                    )
                }
            }
        }
    }