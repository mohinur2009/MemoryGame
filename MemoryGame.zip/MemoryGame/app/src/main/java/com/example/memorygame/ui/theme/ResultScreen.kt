package com.example.memorygame.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.memorygame.game.GameViewModel
import com.example.memorygame.model.BoardTheme
import com.example.memorygame.model.Player
import com.example.memorygame.ui.theme.components.ConfettiRain
import com.example.memorygame.ui.theme.components.MascotView
import com.example.memorygame.ui.theme.components.PillButton
import com.example.memorygame.ui.theme.components.ThemedBackground
import com.example.memorygame.ui.theme.Palettes
import com.example.memorygame.ui.theme.ThemePalette
import kotlinx.coroutines.delay

@Composable
fun ResultScreen(viewModel: GameViewModel) {
    val settings = viewModel.settings.value
    val wordList = viewModel.findWordList(settings.wordListId)
    var theme = BoardTheme.SEA
    if (wordList != null) {
        theme = wordList.theme
    }
    val palette = Palettes.forTheme(theme)
    BackHandler(enabled = true) {
        viewModel.backToSettings()
    }
    val transition = rememberInfiniteTransition(label = "trophy")
    val bounce = transition.animateFloat(
        initialValue = 0f,
        targetValue = -36f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "trophyBounce"
    )
    val wiggle = transition.animateFloat(
        initialValue = -10f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900),
            repeatMode = RepeatMode.Reverse
        ),
        label = "trophyWiggle"
    )
    var trophyEmoji = "🏆"
    if (viewModel.isTie()) {
        trophyEmoji = "🤝"
    }
    ThemedBackground(theme = theme) {
        ConfettiRain()
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = trophyEmoji,
                fontSize = 100.sp,
                modifier = Modifier.graphicsLayer {
                    translationY = bounce.value
                    rotationZ = wiggle.value
                }
            )
            Spacer(modifier = Modifier.height(8.dp))
            Card(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = viewModel.resultTitle(),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = palette.accentDark,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = viewModel.resultSubtitle(),
                        fontSize = 18.sp,
                        color = Color(0xFF546E7A),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(18.dp))
                    if (viewModel.players.size < 2) {
                        val stars = viewModel.starCount()
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (starIndex in 0 until 3) {
                                AnimatedStar(starIndex = starIndex, filled = starIndex < stars)
                            }
                        }
                    } else {
                        val winner = viewModel.winnerIndex()
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            for (index in 0 until viewModel.players.size) {
                                ResultPlayerCard(
                                    player = viewModel.players[index],
                                    isWinner = winner == index,
                                    playerIndex = index,
                                    palette = palette
                                )
                            }
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(22.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                PillButton(text = "🔄 Play again", background = palette.accent, textColor = Color.White, onClick = { viewModel.playAgain() })
                PillButton(text = "⚙️ Settings", background = Color.White, textColor = palette.accentDark, onClick = { viewModel.backToSettings() })
            }
        }
    }
}

@Composable
fun AnimatedStar(starIndex: Int, filled: Boolean) {
    val scale = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(300L + starIndex * 250L)
        scale.animateTo(
            targetValue = 1f,
            animationSpec = spring(dampingRatio = 0.4f, stiffness = Spring.StiffnessLow)
        )
    }
    var starAlpha = 1f
    if (!filled) {
        starAlpha = 0.2f
    }
    Text(
        text = "⭐",
        fontSize = 54.sp,
        modifier = Modifier.graphicsLayer {
            scaleX = scale.value
            scaleY = scale.value
            alpha = starAlpha
        }
    )
}

@Composable
fun ResultPlayerCard(player: Player, isWinner: Boolean, playerIndex: Int, palette: ThemePalette) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        if (isWinner) {
            Text(text = "👑", fontSize = 32.sp)
        } else {
            Spacer(modifier = Modifier.height(42.dp))
        }
        MascotView(
            imageName = palette.mascotImage(playerIndex),
            emoji = palette.mascotEmoji(playerIndex),
            mascotSize = 72.dp
        )
        Text(
            text = player.name,
            fontSize = 18.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF263238)
        )
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(palette.playerColor(playerIndex))
                .padding(horizontal = 14.dp, vertical = 6.dp)
        ) {
            Text(
                text = player.score.toString() + " pairs",
                fontSize = 16.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
        }
    }
}