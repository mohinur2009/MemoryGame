package com.example.memorygame.ui.theme

import androidx.compose.ui.graphics.Color
import com.example.memorygame.model.BoardTheme

data class ThemePalette(
    val skyTop: Color,
    val skyBottom: Color,
    val cardBackStart: Color,
    val cardBackEnd: Color,
    val cardBackTextColor: Color,
    val cardFront: Color,
    val accent: Color,
    val accentDark: Color,
    val playerOneColor: Color,
    val playerTwoColor: Color,
    val decorationEmojis: List<String>,
    val playerOneMascotEmoji: String,
    val playerTwoMascotEmoji: String,
    val playerOneMascotImage: String,
    val playerTwoMascotImage: String
) {
    fun mascotImage(playerIndex: Int): String {
        if (playerIndex == 0) {
            return playerOneMascotImage
        }
        return playerTwoMascotImage
    }

    fun mascotEmoji(playerIndex: Int): String {
        if (playerIndex == 0) {
            return playerOneMascotEmoji
        }
        return playerTwoMascotEmoji
    }

    fun playerColor(playerIndex: Int): Color {
        if (playerIndex == 0) {
            return playerOneColor
        }
        return playerTwoColor
    }
}

object Palettes {

    fun forTheme(theme: BoardTheme): ThemePalette {
        if (theme == BoardTheme.WINTER) {
            return ThemePalette(
                skyTop = Color(0xFF5C9BD6),
                skyBottom = Color(0xFFBFE3F7),
                cardBackStart = Color(0xFFEF5350),
                cardBackEnd = Color(0xFFB71C1C),
                cardBackTextColor = Color.White,
                cardFront = Color(0xFFFFF8E1),
                accent = Color(0xFF2E7D32),
                accentDark = Color(0xFF1B5E20),
                playerOneColor = Color(0xFF43A047),
                playerTwoColor = Color(0xFFC62828),
                decorationEmojis = listOf("🎄", "⛄", "🎁", "🎄", "🍭", "⛄", "🎄", "🎁", "🎄"),
                playerOneMascotEmoji = "🧝",
                playerTwoMascotEmoji = "🦉",
                playerOneMascotImage = "mascot_winter_one",
                playerTwoMascotImage = "mascot_winter_two"
            )
        }
        if (theme == BoardTheme.FARM) {
            return ThemePalette(
                skyTop = Color(0xFF81C7F5),
                skyBottom = Color(0xFFC5E1A5),
                cardBackStart = Color(0xFFFFB74D),
                cardBackEnd = Color(0xFFF57C00),
                cardBackTextColor = Color.White,
                cardFront = Color(0xFFFFFDE7),
                accent = Color(0xFFEF6C00),
                accentDark = Color(0xFFBF360C),
                playerOneColor = Color(0xFF8D6E63),
                playerTwoColor = Color(0xFFEC407A),
                decorationEmojis = listOf("🌻", "🌾", "🚜", "🌾", "🌻", "🏡", "🌾", "🌻", "🌾"),
                playerOneMascotEmoji = "🐮",
                playerTwoMascotEmoji = "🐔",
                playerOneMascotImage = "mascot_farm_one",
                playerTwoMascotImage = "mascot_farm_two"
            )
        }
        if (theme == BoardTheme.GARDEN) {
            return ThemePalette(
                skyTop = Color(0xFFF48FB1),
                skyBottom = Color(0xFFC8E6C9),
                cardBackStart = Color(0xFFBA68C8),
                cardBackEnd = Color(0xFF7B1FA2),
                cardBackTextColor = Color.White,
                cardFront = Color(0xFFFFF0F6),
                accent = Color(0xFFD81B60),
                accentDark = Color(0xFF880E4F),
                playerOneColor = Color(0xFFFBC02D),
                playerTwoColor = Color(0xFFE53935),
                decorationEmojis = listOf("🌷", "🌼", "🍄", "🌸", "🌷", "🌻", "🌼", "🌷", "🍄"),
                playerOneMascotEmoji = "🐝",
                playerTwoMascotEmoji = "🐞",
                playerOneMascotImage = "mascot_garden_one",
                playerTwoMascotImage = "mascot_garden_two"
            )
        }
        if (theme == BoardTheme.CLASSROOM) {
            return ThemePalette(
                skyTop = Color(0xFF7986CB),
                skyBottom = Color(0xFF3949AB),
                cardBackStart = Color(0xFF4FC3F7),
                cardBackEnd = Color(0xFF0277BD),
                cardBackTextColor = Color.White,
                cardFront = Color(0xFFF1F8FF),
                accent = Color(0xFF3949AB),
                accentDark = Color(0xFF1A237E),
                playerOneColor = Color(0xFFFF7043),
                playerTwoColor = Color(0xFF26A69A),
                decorationEmojis = listOf("✏️", "📚", "🎒", "📐", "✏️", "🖍️", "📚", "🎒", "✏️"),
                playerOneMascotEmoji = "🦊",
                playerTwoMascotEmoji = "🐼",
                playerOneMascotImage = "mascot_classroom_one",
                playerTwoMascotImage = "mascot_classroom_two"
            )
        }
        return ThemePalette(
            skyTop = Color(0xFF8EDBF7),
            skyBottom = Color(0xFF2E9FD9),
            cardBackStart = Color(0xFFFFF176),
            cardBackEnd = Color(0xFFFFD600),
            cardBackTextColor = Color(0xFF1A1A1A),
            cardFront = Color(0xFFE3F7FF),
            accent = Color(0xFF0288D1),
            accentDark = Color(0xFF01579B),
            playerOneColor = Color(0xFF9C6ADE),
            playerTwoColor = Color(0xFFE53935),
            decorationEmojis = listOf("🐚", "🌿", "🐠", "⭐", "🌿", "🐡", "🐚", "🌿", "⭐"),
            playerOneMascotEmoji = "🐙",
            playerTwoMascotEmoji = "🦀",
            playerOneMascotImage = "mascot_sea_one",
            playerTwoMascotImage = "mascot_sea_two"
        )
    }
}