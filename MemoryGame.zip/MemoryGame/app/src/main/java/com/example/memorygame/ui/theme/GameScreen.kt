package com.example.memorygame.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.memorygame.ui.theme.components.CardPicture
import com.example.memorygame.ui.theme.components.ConfettiBurst
import com.example.memorygame.ui.theme.components.InfoChip
import com.example.memorygame.ui.theme.components.MascotView
import com.example.memorygame.ui.theme.components.PillButton
import com.example.memorygame.ui.theme.components.softTextShadow
import com.example.memorygame.game.GameRules
import com.example.memorygame.game.GameViewModel
import com.example.memorygame.model.BoardTheme
import com.example.memorygame.model.CardFace
import com.example.memorygame.model.MemoryCard
import com.example.memorygame.model.Player
import com.example.memorygame.ui.theme.components.ThemedBackground
import com.example.memorygame.ui.theme.Palettes
import com.example.memorygame.ui.theme.ThemePalette
import kotlinx.coroutines.delay

private const val CARD_ASPECT_RATIO: Float = 0.82f

private val celebrationMessages: List<String> = listOf(
    "Great match!",
    "Super!",
    "Awesome!",
    "You got it!",
    "Wow!",
    "Brilliant!"
)

@Composable
fun GameScreen(viewModel: GameViewModel) {
    val settings = viewModel.settings.value
    val wordList = viewModel.findWordList(settings.wordListId)
    var theme = BoardTheme.SEA
    if (wordList != null) {
        theme = wordList.theme
    }
    val palette = Palettes.forTheme(theme)
    BackHandler(enabled = true) {
        viewModel.backToSettings()
    }
    ThemedBackground(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 44.dp)
        ) {
            GameTopBar(viewModel = viewModel, palette = palette)
            Spacer(modifier = Modifier.height(8.dp))
            BoxWithConstraints(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                if (maxWidth > maxHeight) {
                    LandscapeBoard(viewModel = viewModel, palette = palette)
                } else {
                    PortraitBoard(viewModel = viewModel, palette = palette)
                }
            }
        }
        val celebrationId = viewModel.matchCelebrationId.value
        if (celebrationId > 0) {
            val message = celebrationMessages[celebrationId % celebrationMessages.size]
            ConfettiBurst(burstId = celebrationId, message = message)
        }
    }
}

@Composable
fun GameTopBar(viewModel: GameViewModel, palette: ThemePalette) {
    val pairsText = "🎯 " + viewModel.matchedPairCount() + "/" + viewModel.totalPairCount()
    val movesText = "👆 " + viewModel.moves.value
    val timeText = "⏱ " + GameRules.formatTime(viewModel.elapsedSeconds.value)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        PillButton(text = "🏠", background = Color.White, textColor = palette.accentDark, onClick = { viewModel.backToSettings() })
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            InfoChip(text = pairsText, textColor = palette.accentDark)
            InfoChip(text = movesText, textColor = palette.accentDark)
            InfoChip(text = timeText, textColor = palette.accentDark)
        }
        PillButton(text = "🔄", background = palette.accent, textColor = Color.White, onClick = { viewModel.startGame() })
    }
}

@Composable
fun LandscapeBoard(viewModel: GameViewModel, palette: ThemePalette) {
    Row(
        modifier = Modifier.fillMaxSize(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        PlayerSlot(viewModel = viewModel, index = 0, palette = palette, compact = false, modifier = Modifier.width(130.dp))
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
        ) {
            CardGrid(viewModel = viewModel, palette = palette)
        }
        if (viewModel.players.size > 1) {
            PlayerSlot(viewModel = viewModel, index = 1, palette = palette, compact = false, modifier = Modifier.width(130.dp))
        } else {
            Spacer(modifier = Modifier.width(130.dp))
        }
    }
}

@Composable
fun PortraitBoard(viewModel: GameViewModel, palette: ThemePalette) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PlayerSlot(viewModel = viewModel, index = 0, palette = palette, compact = true, modifier = Modifier)
            if (viewModel.players.size > 1) {
                PlayerSlot(viewModel = viewModel, index = 1, palette = palette, compact = true, modifier = Modifier)
            }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            CardGrid(viewModel = viewModel, palette = palette)
        }
    }
}

@Composable
fun PlayerSlot(viewModel: GameViewModel, index: Int, palette: ThemePalette, compact: Boolean, modifier: Modifier) {
    if (index >= viewModel.players.size) {
        return
    }
    val player = viewModel.players[index]
    val isSinglePlayer = viewModel.players.size == 1
    var isActive = viewModel.currentPlayerIndex.value == index
    var badgeText = "Your turn!"
    if (isSinglePlayer) {
        isActive = true
        badgeText = "Keep going!"
    }
    PlayerPanel(
        player = player,
        isActive = isActive,
        badgeText = badgeText,
        mascotImage = palette.mascotImage(index),
        mascotEmoji = palette.mascotEmoji(index),
        playerColor = palette.playerColor(index),
        compact = compact,
        modifier = modifier
    )
}

@Composable
fun PlayerPanel(
    player: Player,
    isActive: Boolean,
    badgeText: String,
    mascotImage: String,
    mascotEmoji: String,
    playerColor: Color,
    compact: Boolean,
    modifier: Modifier
) {
    val transition = rememberInfiniteTransition(label = "mascotBob")
    val bob = transition.animateFloat(
        initialValue = 0f,
        targetValue = -18f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 550),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bobOffset"
    )
    val badgePulse = transition.animateFloat(
        initialValue = 0.92f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "badgePulse"
    )
    val scoreScale = remember { Animatable(1f) }
    LaunchedEffect(player.score) {
        if (player.score > 0) {
            scoreScale.animateTo(targetValue = 1.4f, animationSpec = tween(durationMillis = 140))
            scoreScale.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.35f, stiffness = Spring.StiffnessMediumLow)
            )
        }
    }
    var mascotOffset = 0f
    var ringColor = Color.White
    var panelAlpha = 0.6f
    if (isActive) {
        mascotOffset = bob.value
        ringColor = playerColor
        panelAlpha = 1f
    }
    if (compact) {
        Row(
            modifier = modifier.graphicsLayer {
                alpha = panelAlpha
            },
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(modifier = Modifier.graphicsLayer { translationY = mascotOffset }) {
                MascotView(imageName = mascotImage, emoji = mascotEmoji, mascotSize = 50.dp)
            }
            Spacer(modifier = Modifier.width(4.dp))
            ScoreBubble(score = player.score, ringColor = ringColor, fillColor = playerColor, bubbleSize = 52.dp, scale = scoreScale.value)
            Spacer(modifier = Modifier.width(6.dp))
            Column {
                Text(
                    text = player.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    style = softTextShadow
                )
                if (isActive) {
                    TurnBadge(text = badgeText, color = playerColor, pulse = badgePulse.value)
                }
            }
        }
    } else {
        Column(
            modifier = modifier.graphicsLayer {
                alpha = panelAlpha
            },
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(modifier = Modifier.graphicsLayer { translationY = mascotOffset }) {
                MascotView(imageName = mascotImage, emoji = mascotEmoji, mascotSize = 80.dp)
            }
            ScoreBubble(score = player.score, ringColor = ringColor, fillColor = playerColor, bubbleSize = 78.dp, scale = scoreScale.value)
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = player.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White,
                style = softTextShadow,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(4.dp))
            if (isActive) {
                TurnBadge(text = badgeText, color = playerColor, pulse = badgePulse.value)
            }
        }
    }
}

@Composable
fun ScoreBubble(score: Int, ringColor: Color, fillColor: Color, bubbleSize: Dp, scale: Float) {
    val scoreFontSize = with(LocalDensity.current) { (bubbleSize * 0.45f).toSp() }
    Box(
        modifier = Modifier
            .size(bubbleSize)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .shadow(elevation = 8.dp, shape = CircleShape)
            .clip(CircleShape)
            .background(Brush.radialGradient(colors = listOf(Color.White, fillColor.copy(alpha = 0.55f))))
            .border(width = 4.dp, color = ringColor, shape = CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = score.toString(),
            fontSize = scoreFontSize,
            fontWeight = FontWeight.ExtraBold,
            color = Color(0xFF1B1B1B)
        )
    }
}

@Composable
fun TurnBadge(text: String, color: Color, pulse: Float) {
    Box(
        modifier = Modifier
            .graphicsLayer {
                scaleX = pulse
                scaleY = pulse
            }
            .clip(RoundedCornerShape(50))
            .background(color)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(text = text, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
    }
}

fun computeCardWidth(availableWidth: Dp, availableHeight: Dp, columns: Int, rows: Int, spacing: Dp): Dp {
    val widthPerCard = (availableWidth - spacing * (columns - 1)) / columns
    val heightPerCard = (availableHeight - spacing * (rows - 1)) / rows
    val widthFromHeight = heightPerCard * CARD_ASPECT_RATIO
    if (widthFromHeight < widthPerCard) {
        return widthFromHeight
    }
    return widthPerCard
}

@Composable
fun CardGrid(viewModel: GameViewModel, palette: ThemePalette) {
    val cardCount = viewModel.cards.size
    if (cardCount == 0) {
        return
    }
    val showNumbers = viewModel.settings.value.showNumbers
    val shakeKey = viewModel.mismatchShakeId.value
    BoxWithConstraints(
        modifier = Modifier.fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        val spacing = 10.dp
        var bestColumns = 4
        var bestWidth = 0.dp
        for (candidateColumns in 2..6) {
            if (cardCount % candidateColumns == 0) {
                val candidateRows = cardCount / candidateColumns
                val candidateWidth = computeCardWidth(maxWidth, maxHeight, candidateColumns, candidateRows, spacing)
                if (candidateWidth > bestWidth) {
                    bestWidth = candidateWidth
                    bestColumns = candidateColumns
                }
            }
        }
        var rows = cardCount / bestColumns
        if (cardCount % bestColumns != 0) {
            rows = rows + 1
        }
        if (bestWidth == 0.dp) {
            bestWidth = computeCardWidth(maxWidth, maxHeight, bestColumns, rows, spacing)
        }
        var cardWidth = bestWidth
        if (cardWidth > 170.dp) {
            cardWidth = 170.dp
        }
        val cardHeight = cardWidth / CARD_ASPECT_RATIO
        Column(
            verticalArrangement = Arrangement.spacedBy(spacing),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            for (rowIndex in 0 until rows) {
                Row(horizontalArrangement = Arrangement.spacedBy(spacing)) {
                    for (columnIndex in 0 until bestColumns) {
                        val position = rowIndex * bestColumns + columnIndex
                        if (position < cardCount) {
                            val card = viewModel.cards[position]
                            val shouldShake = viewModel.mismatchPositions.contains(position)
                            MemoryCardView(
                                card = card,
                                cardNumber = position + 1,
                                showNumber = showNumbers,
                                palette = palette,
                                cardWidth = cardWidth,
                                cardHeight = cardHeight,
                                shakeKey = shakeKey,
                                shouldShake = shouldShake,
                                onClick = { viewModel.onCardTapped(position) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MemoryCardView(
    card: MemoryCard,
    cardNumber: Int,
    showNumber: Boolean,
    palette: ThemePalette,
    cardWidth: Dp,
    cardHeight: Dp,
    shakeKey: Int,
    shouldShake: Boolean,
    onClick: () -> Unit
) {
    var targetRotation = 0f
    if (card.isFaceUp || card.isMatched) {
        targetRotation = 180f
    }
    val rotation = animateFloatAsState(
        targetValue = targetRotation,
        animationSpec = tween(durationMillis = 450, easing = FastOutSlowInEasing),
        label = "cardFlip"
    )
    var targetAlpha = 1f
    if (card.isMatched) {
        targetAlpha = 0.85f
    }
    val fade = animateFloatAsState(
        targetValue = targetAlpha,
        animationSpec = tween(durationMillis = 600),
        label = "cardFade"
    )
    val bounce = remember { Animatable(1f) }
    val shake = remember { Animatable(0f) }
    LaunchedEffect(card.isMatched) {
        if (card.isMatched) {
            bounce.animateTo(targetValue = 1.18f, animationSpec = tween(durationMillis = 160))
            bounce.animateTo(
                targetValue = 1f,
                animationSpec = spring(dampingRatio = 0.3f, stiffness = Spring.StiffnessMedium)
            )
        }
    }
    LaunchedEffect(shakeKey) {
        if (shouldShake && shakeKey > 0) {
            delay(450L)
            for (step in 0 until 3) {
                shake.animateTo(targetValue = 16f, animationSpec = tween(durationMillis = 55))
                shake.animateTo(targetValue = -16f, animationSpec = tween(durationMillis = 55))
            }
            shake.animateTo(targetValue = 0f, animationSpec = tween(durationMillis = 55))
        }
    }
    var borderColor = Color.White
    var borderWidth = 3.dp
    if (card.isMatched) {
        borderColor = Color(0xFF43A047)
        borderWidth = 4.dp
    } else if (card.isFaceUp) {
        borderColor = palette.accent
    }
    val isTappable = !card.isFaceUp && !card.isMatched
    Card(
        onClick = { onClick() },
        enabled = isTappable,
        modifier = Modifier
            .size(width = cardWidth, height = cardHeight)
            .graphicsLayer {
                rotationY = rotation.value
                cameraDistance = 14f * density
                scaleX = bounce.value
                scaleY = bounce.value
                translationX = shake.value
                alpha = fade.value
            },
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(width = borderWidth, color = borderColor),
        colors = CardDefaults.cardColors(
            containerColor = Color.White,
            disabledContainerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp, disabledElevation = 6.dp)
    ) {
        if (rotation.value <= 90f) {
            CardBack(cardNumber = cardNumber, showNumber = showNumber, palette = palette, cardWidth = cardWidth)
        } else {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        rotationY = 180f
                    }
            ) {
                CardFront(card = card, palette = palette, cardWidth = cardWidth)
            }
        }
    }
}

@Composable
fun CardBack(cardNumber: Int, showNumber: Boolean, palette: ThemePalette, cardWidth: Dp) {
    val numberSize = with(LocalDensity.current) { (cardWidth * 0.4f).toSp() }
    val sparkleSize = with(LocalDensity.current) { (cardWidth * 0.13f).toSp() }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.linearGradient(colors = listOf(palette.cardBackStart, palette.cardBackEnd))),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
                .border(width = 2.dp, color = Color.White.copy(alpha = 0.7f), shape = RoundedCornerShape(12.dp))
        )
        Text(
            text = "✦",
            fontSize = sparkleSize,
            color = Color.White.copy(alpha = 0.8f),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(10.dp)
        )
        Text(
            text = "✦",
            fontSize = sparkleSize,
            color = Color.White.copy(alpha = 0.8f),
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(10.dp)
        )
        if (showNumber) {
            Text(
                text = cardNumber.toString(),
                fontSize = numberSize,
                fontWeight = FontWeight.ExtraBold,
                color = palette.cardBackTextColor
            )
        } else {
            Text(
                text = "?",
                fontSize = numberSize,
                fontWeight = FontWeight.ExtraBold,
                color = palette.cardBackTextColor.copy(alpha = 0.55f)
            )
        }
    }
}

@Composable
fun CardFront(card: MemoryCard, palette: ThemePalette, cardWidth: Dp) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(colors = listOf(Color.White, palette.cardFront))),
        contentAlignment = Alignment.Center
    ) {
        if (card.face == CardFace.PICTURE) {
            CardPicture(
                item = card.item,
                pictureSize = cardWidth,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(10.dp)
            )
        } else if (card.face == CardFace.WORD) {
            WordText(word = card.item.word, baseWidth = cardWidth, color = palette.accentDark)
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                CardPicture(
                    item = card.item,
                    pictureSize = cardWidth * 0.75f,
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                )
                WordText(word = card.item.word, baseWidth = cardWidth * 0.7f, color = palette.accentDark)
            }
        }
        if (card.isMatched) {
            Text(
                text = "✨",
                fontSize = 18.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
            )
        }
    }
}

@Composable
fun WordText(word: String, baseWidth: Dp, color: Color) {
    var factor = 0.24f
    if (word.length > 5) {
        factor = 0.19f
    }
    if (word.length > 8) {
        factor = 0.15f
    }
    val wordFontSize = with(LocalDensity.current) { (baseWidth * factor).toSp() }
    Text(
        text = word,
        fontSize = wordFontSize,
        fontWeight = FontWeight.ExtraBold,
        color = color,
        textAlign = TextAlign.Center,
        maxLines = 2,
        modifier = Modifier.padding(horizontal = 4.dp)
    )
}