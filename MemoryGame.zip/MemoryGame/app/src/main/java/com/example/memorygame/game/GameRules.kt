package com.example.memorygame.game

import com.example.memorygame.model.CardFace
import com.example.memorygame.model.MatchMode

object GameRules {

    val cardCountOptions: List<Int> = listOf(6, 8, 12, 16)

    const val MIN_DELAY_SECONDS: Float = 0.5f
    const val MAX_DELAY_SECONDS: Float = 5f
    const val MAX_NAME_LENGTH: Int = 12

    fun pairsFor(cardCount: Int): Int {
        return cardCount / 2
    }

    fun facesFor(mode: MatchMode): List<CardFace> {
        if (mode == MatchMode.PICTURES) {
            return listOf(CardFace.PICTURE, CardFace.PICTURE)
        }
        if (mode == MatchMode.WORDS) {
            return listOf(CardFace.WORD, CardFace.WORD)
        }
        if (mode == MatchMode.PICTURES_WITH_WORDS) {
            return listOf(CardFace.PICTURE_AND_WORD, CardFace.PICTURE_AND_WORD)
        }
        return listOf(CardFace.PICTURE, CardFace.WORD)
    }

    fun difficultyEmoji(cardCount: Int): String {
        if (cardCount <= 6) {
            return "🐣"
        }
        if (cardCount <= 8) {
            return "🐥"
        }
        if (cardCount <= 12) {
            return "🦊"
        }
        return "🦁"
    }

    fun difficultyLabel(cardCount: Int): String {
        if (cardCount <= 6) {
            return "Easy"
        }
        if (cardCount <= 8) {
            return "Medium"
        }
        if (cardCount <= 12) {
            return "Hard"
        }
        return "Expert"
    }

    fun formatTime(totalSeconds: Int): String {
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        var minutesText = minutes.toString()
        if (minutes < 10) {
            minutesText = "0" + minutesText
        }
        var secondsText = seconds.toString()
        if (seconds < 10) {
            secondsText = "0" + secondsText
        }
        return minutesText + ":" + secondsText
    }
}