package com.example.memorygame.game

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.memorygame.model.GameSettings
import com.example.memorygame.model.MatchMode
import com.example.memorygame.model.MemoryCard
import com.example.memorygame.model.Player
import com.example.memorygame.model.Screen
import com.example.memorygame.model.WordItem
import com.example.memorygame.model.WordList
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class GameViewModel : ViewModel() {

    val wordLists = mutableStateListOf<WordList>()
    val screen = mutableStateOf(Screen.SETTINGS)
    val settings = mutableStateOf(createDefaultSettings())
    val cards = mutableStateListOf<MemoryCard>()
    val players = mutableStateListOf<Player>()
    val currentPlayerIndex = mutableStateOf(0)
    val moves = mutableStateOf(0)
    val elapsedSeconds = mutableStateOf(0)
    val matchCelebrationId = mutableStateOf(0)
    val mismatchShakeId = mutableStateOf(0)
    val mismatchPositions = mutableStateListOf<Int>()

    private var isBoardLocked: Boolean = false
    private var firstSelectedPosition: Int = -1
    private var secondSelectedPosition: Int = -1
    private var gameSessionId: Int = 0
    private var timerJob: Job? = null
    private var hasLoadedWordLists: Boolean = false

    private fun createDefaultSettings(): GameSettings {
        return GameSettings(
            wordListId = "",
            selectedWordIds = HashSet(),
            cardCount = 12,
            matchMode = MatchMode.PICTURES,
            showNumbers = true,
            flipBackDelayMillis = 1500L,
            playerCount = 2,
            playerOneName = "Player 1",
            playerTwoName = "Player 2"
        )
    }

    fun loadWordLists(loadedLists: List<WordList>) {
        if (hasLoadedWordLists) {
            return
        }
        hasLoadedWordLists = true
        wordLists.clear()
        wordLists.addAll(loadedLists)
        if (loadedLists.isNotEmpty()) {
            val firstList = loadedLists[0]
            var startingMode = MatchMode.PICTURES
            if (!firstList.hasPictures) {
                startingMode = MatchMode.WORDS
            }
            settings.value = settings.value.copy(
                wordListId = firstList.id,
                selectedWordIds = collectAllIds(firstList),
                matchMode = startingMode
            )
        }
    }

    private fun collectAllIds(wordList: WordList): Set<String> {
        val ids = HashSet<String>()
        for (item in wordList.items) {
            ids.add(item.id)
        }
        return ids
    }

    fun findWordList(listId: String): WordList? {
        for (wordList in wordLists) {
            if (wordList.id == listId) {
                return wordList
            }
        }
        return null
    }

    fun isModeAvailable(mode: MatchMode): Boolean {
        if (mode == MatchMode.WORDS) {
            return true
        }
        val wordList = findWordList(settings.value.wordListId)
        if (wordList == null) {
            return false
        }
        return wordList.hasPictures
    }

    fun selectWordList(listId: String) {
        val wordList = findWordList(listId)
        if (wordList == null) {
            return
        }
        var mode = settings.value.matchMode
        if (!wordList.hasPictures) {
            mode = MatchMode.WORDS
        }
        settings.value = settings.value.copy(
            wordListId = wordList.id,
            selectedWordIds = collectAllIds(wordList),
            matchMode = mode
        )
    }

    fun toggleWord(wordId: String) {
        val current = settings.value
        val newIds = HashSet<String>(current.selectedWordIds)
        if (newIds.contains(wordId)) {
            newIds.remove(wordId)
        } else {
            newIds.add(wordId)
        }
        settings.value = current.copy(selectedWordIds = newIds)
    }

    fun selectAllWords() {
        val wordList = findWordList(settings.value.wordListId)
        if (wordList == null) {
            return
        }
        settings.value = settings.value.copy(selectedWordIds = collectAllIds(wordList))
    }

    fun clearWords() {
        settings.value = settings.value.copy(selectedWordIds = HashSet())
    }

    fun setCardCount(count: Int) {
        settings.value = settings.value.copy(cardCount = count)
    }

    fun setMatchMode(mode: MatchMode) {
        if (!isModeAvailable(mode)) {
            return
        }
        settings.value = settings.value.copy(matchMode = mode)
    }

    fun setShowNumbers(show: Boolean) {
        settings.value = settings.value.copy(showNumbers = show)
    }

    fun setPlayerCount(count: Int) {
        settings.value = settings.value.copy(playerCount = count)
    }

    fun setPlayerOneName(name: String) {
        settings.value = settings.value.copy(playerOneName = limitName(name))
    }

    fun setPlayerTwoName(name: String) {
        settings.value = settings.value.copy(playerTwoName = limitName(name))
    }

    private fun limitName(name: String): String {
        if (name.length > GameRules.MAX_NAME_LENGTH) {
            return name.substring(0, GameRules.MAX_NAME_LENGTH)
        }
        return name
    }

    private fun cleanName(name: String, fallback: String): String {
        val trimmed = name.trim()
        if (trimmed.isEmpty()) {
            return fallback
        }
        return trimmed
    }

    fun setFlipBackDelay(seconds: Float) {
        val rounded = Math.round(seconds * 2f) / 2f
        var safeSeconds = rounded
        if (safeSeconds < GameRules.MIN_DELAY_SECONDS) {
            safeSeconds = GameRules.MIN_DELAY_SECONDS
        }
        if (safeSeconds > GameRules.MAX_DELAY_SECONDS) {
            safeSeconds = GameRules.MAX_DELAY_SECONDS
        }
        val millis = (safeSeconds * 1000f).toLong()
        settings.value = settings.value.copy(flipBackDelayMillis = millis)
    }

    fun selectedWordCount(): Int {
        return settings.value.selectedWordIds.size
    }

    fun requiredWordCount(): Int {
        return GameRules.pairsFor(settings.value.cardCount)
    }

    fun canStartGame(): Boolean {
        val wordList = findWordList(settings.value.wordListId)
        if (wordList == null) {
            return false
        }
        return selectedWordCount() >= requiredWordCount()
    }

    fun startGame() {
        val currentSettings = settings.value
        val wordList = findWordList(currentSettings.wordListId)
        if (wordList == null) {
            return
        }
        val pairCount = GameRules.pairsFor(currentSettings.cardCount)
        val chosenItems = ArrayList<WordItem>()
        for (item in wordList.items) {
            if (currentSettings.selectedWordIds.contains(item.id)) {
                chosenItems.add(item)
            }
        }
        if (chosenItems.size < pairCount) {
            return
        }
        chosenItems.shuffle()
        val faces = GameRules.facesFor(currentSettings.matchMode)
        val newCards = ArrayList<MemoryCard>()
        for (pairIndex in 0 until pairCount) {
            val item = chosenItems[pairIndex]
            for (faceIndex in 0 until faces.size) {
                val card = MemoryCard(
                    position = 0,
                    pairKey = item.id,
                    item = item,
                    face = faces[faceIndex],
                    isFaceUp = false,
                    isMatched = false
                )
                newCards.add(card)
            }
        }
        newCards.shuffle()
        cards.clear()
        for (index in 0 until newCards.size) {
            val positionedCard = newCards[index].copy(position = index)
            cards.add(positionedCard)
        }
        players.clear()
        players.add(Player(name = cleanName(currentSettings.playerOneName, "Player 1"), score = 0))
        if (currentSettings.playerCount == 2) {
            players.add(Player(name = cleanName(currentSettings.playerTwoName, "Player 2"), score = 0))
        }
        currentPlayerIndex.value = 0
        moves.value = 0
        elapsedSeconds.value = 0
        mismatchPositions.clear()
        firstSelectedPosition = -1
        secondSelectedPosition = -1
        isBoardLocked = false
        gameSessionId = gameSessionId + 1
        startTimer()
        screen.value = Screen.GAME
    }

    fun onCardTapped(position: Int) {
        if (screen.value != Screen.GAME) {
            return
        }
        if (isBoardLocked) {
            return
        }
        if (position < 0 || position >= cards.size) {
            return
        }
        if (position == firstSelectedPosition) {
            return
        }
        val card = cards[position]
        if (card.isFaceUp || card.isMatched) {
            return
        }
        cards[position] = card.copy(isFaceUp = true)
        if (firstSelectedPosition == -1) {
            firstSelectedPosition = position
            return
        }
        secondSelectedPosition = position
        moves.value = moves.value + 1
        isBoardLocked = true
        evaluateSelectedPair()
    }

    private fun evaluateSelectedPair() {
        val firstPosition = firstSelectedPosition
        val secondPosition = secondSelectedPosition
        val sessionAtStart = gameSessionId
        val firstCard = cards[firstPosition]
        val secondCard = cards[secondPosition]
        if (firstCard.pairKey == secondCard.pairKey) {
            viewModelScope.launch {
                delay(500L)
                if (sessionAtStart == gameSessionId) {
                    handleMatch(firstPosition, secondPosition)
                }
            }
        } else {
            mismatchPositions.clear()
            mismatchPositions.add(firstPosition)
            mismatchPositions.add(secondPosition)
            mismatchShakeId.value = mismatchShakeId.value + 1
            viewModelScope.launch {
                delay(450L)
                delay(settings.value.flipBackDelayMillis)
                if (sessionAtStart == gameSessionId) {
                    handleMismatch(firstPosition, secondPosition)
                }
            }
        }
    }

    private fun handleMatch(firstPosition: Int, secondPosition: Int) {
        cards[firstPosition] = cards[firstPosition].copy(isMatched = true)
        cards[secondPosition] = cards[secondPosition].copy(isMatched = true)
        addPointToCurrentPlayer()
        matchCelebrationId.value = matchCelebrationId.value + 1
        clearSelection()
        if (areAllCardsMatched()) {
            finishGame()
        } else {
            isBoardLocked = false
        }
    }

    private fun handleMismatch(firstPosition: Int, secondPosition: Int) {
        cards[firstPosition] = cards[firstPosition].copy(isFaceUp = false)
        cards[secondPosition] = cards[secondPosition].copy(isFaceUp = false)
        mismatchPositions.clear()
        clearSelection()
        switchToNextPlayer()
        isBoardLocked = false
    }

    private fun clearSelection() {
        firstSelectedPosition = -1
        secondSelectedPosition = -1
    }

    private fun addPointToCurrentPlayer() {
        val index = currentPlayerIndex.value
        if (index >= 0 && index < players.size) {
            val player = players[index]
            players[index] = player.copy(score = player.score + 1)
        }
    }

    private fun switchToNextPlayer() {
        if (players.size > 1) {
            val nextIndex = (currentPlayerIndex.value + 1) % players.size
            currentPlayerIndex.value = nextIndex
        }
    }

    private fun areAllCardsMatched(): Boolean {
        for (card in cards) {
            if (!card.isMatched) {
                return false
            }
        }
        return true
    }

    private fun finishGame() {
        stopTimer()
        val sessionAtFinish = gameSessionId
        viewModelScope.launch {
            delay(1300L)
            if (sessionAtFinish == gameSessionId) {
                screen.value = Screen.RESULT
            }
        }
    }

    fun playAgain() {
        startGame()
    }

    fun backToSettings() {
        stopTimer()
        gameSessionId = gameSessionId + 1
        isBoardLocked = false
        clearSelection()
        mismatchPositions.clear()
        screen.value = Screen.SETTINGS
    }

    fun matchedPairCount(): Int {
        var matchedCards = 0
        for (card in cards) {
            if (card.isMatched) {
                matchedCards = matchedCards + 1
            }
        }
        return matchedCards / 2
    }

    fun totalPairCount(): Int {
        return cards.size / 2
    }

    fun isTie(): Boolean {
        if (players.size < 2) {
            return false
        }
        return players[0].score == players[1].score
    }

    fun winnerIndex(): Int {
        if (players.size < 2) {
            return 0
        }
        if (players[0].score > players[1].score) {
            return 0
        }
        if (players[1].score > players[0].score) {
            return 1
        }
        return -1
    }

    fun resultTitle(): String {
        if (players.size < 2) {
            return "Amazing memory!"
        }
        val winner = winnerIndex()
        if (winner == -1) {
            return "It's a tie!"
        }
        return players[winner].name + " wins!"
    }

    fun resultSubtitle(): String {
        val timeText = GameRules.formatTime(elapsedSeconds.value)
        if (players.size < 2) {
            return "You found all " + totalPairCount() + " pairs in " + moves.value + " moves (" + timeText + ")"
        }
        return players[0].name + "  " + players[0].score + " : " + players[1].score + "  " + players[1].name
    }

    fun starCount(): Int {
        val pairs = totalPairCount()
        if (pairs == 0) {
            return 0
        }
        val movesMade = moves.value
        if (movesMade <= pairs + pairs / 2) {
            return 3
        }
        if (movesMade <= pairs * 2 + pairs / 2) {
            return 2
        }
        return 1
    }

    private fun startTimer() {
        stopTimer()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                elapsedSeconds.value = elapsedSeconds.value + 1
            }
        }
    }

    private fun stopTimer() {
        val job = timerJob
        if (job != null) {
            job.cancel()
        }
        timerJob = null
    }

    override fun onCleared() {
        stopTimer()
        super.onCleared()
    }
}