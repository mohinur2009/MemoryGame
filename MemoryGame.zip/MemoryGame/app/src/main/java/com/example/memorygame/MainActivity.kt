package com.example.memorygame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModelProvider
import com.example.memorygame.data.WordRepository
import com.example.memorygame.game.GameViewModel
import com.example.memorygame.model.Screen
import com.example.memorygame.ui.GameScreen
import com.example.memorygame.ui.ResultScreen
import com.example.memorygame.ui.SettingsScreen

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val gameViewModel = ViewModelProvider(this).get(GameViewModel::class.java)
        val repository = WordRepository(applicationContext)
        val loadedLists = repository.loadWordLists()
        gameViewModel.loadWordLists(loadedLists)
        setContent {
            MemoryGameApp(viewModel = gameViewModel)
        }
    }
}

@Composable
fun MemoryGameApp(viewModel: GameViewModel) {
    MaterialTheme {
        val currentScreen = viewModel.screen.value
        if (currentScreen == Screen.SETTINGS) {
            SettingsScreen(viewModel = viewModel)
        } else if (currentScreen == Screen.GAME) {
            GameScreen(viewModel = viewModel)
        } else {
            ResultScreen(viewModel = viewModel)
        }
    }
}