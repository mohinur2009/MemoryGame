package com.example.memorygame.model


enum class MatchMode(val title: String, val subtitle: String, val emoji: String) {
    PICTURES("Pictures", "Picture with the same picture", "🖼️ 🖼️"),
    WORDS("Words", "Word with the same word", "🔤 🔤"),
    PICTURES_WITH_WORDS("Pictures + Words", "Both cards show picture and word", "🖼️🔤"),
    PICTURES_TO_WORDS("Picture to Word", "Find the word for each picture", "🖼️ ➡️ 🔤")
}

enum class CardFace {
    PICTURE,
    WORD,
    PICTURE_AND_WORD
}

enum class BoardTheme {
    SEA,
    WINTER,
    FARM,
    GARDEN,
    CLASSROOM
}

enum class Screen {
    SETTINGS,
    GAME,
    RESULT
}

data class WordItem(
    val id: String,
    val word: String,
    val imageName: String,
    val emoji: String
)

data class WordList(
    val id: String,
    val title: String,
    val iconEmoji: String,
    val theme: BoardTheme,
    val hasPictures: Boolean,
    val items: List<WordItem>
)

data class GameSettings(
    val wordListId: String,
    val selectedWordIds: Set<String>,
    val cardCount: Int,
    val matchMode: MatchMode,
    val showNumbers: Boolean,
    val flipBackDelayMillis: Long,
    val playerCount: Int,
    val playerOneName: String,
    val playerTwoName: String
)

data class MemoryCard(
    val position: Int,
    val pairKey: String,
    val item: WordItem,
    val face: CardFace,
    val isFaceUp: Boolean,
    val isMatched: Boolean
)

data class Player(
    val name: String,
    val score: Int
)