package com.example.memorygame.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.memorygame.ui.theme.components.PillButton
import com.example.memorygame.ui.theme.components.ThemedBackground
import com.example.memorygame.game.GameRules
import com.example.memorygame.game.GameViewModel
import com.example.memorygame.model.BoardTheme
import com.example.memorygame.model.MatchMode
import com.example.memorygame.model.WordItem
import com.example.memorygame.model.WordList
import com.example.memorygame.ui.theme.components.softTextShadow

import com.example.memorygame.ui.theme.Palettes
import com.example.memorygame.ui.theme.ThemePalette
import kotlin.math.sin

@Composable
fun SettingsScreen(viewModel: GameViewModel) {
    val settings = viewModel.settings.value
    val selectedList = viewModel.findWordList(settings.wordListId)
    var theme = BoardTheme.SEA
    if (selectedList != null) {
        theme = selectedList.theme
    }
    val palette = Palettes.forTheme(theme)
    ThemedBackground(theme = theme) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .verticalScroll(rememberScrollState())
                .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 60.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            GameTitle()
            Spacer(modifier = Modifier.height(16.dp))
            if (viewModel.wordLists.isEmpty()) {
                SettingsSection(title = "No word lists yet", palette = palette) {
                    Text(
                        text = "Put word_lists.json inside app/src/main/assets and run the app again.",
                        fontSize = 16.sp
                    )
                }
            } else {
                WordListSection(viewModel = viewModel, palette = palette)
                if (selectedList != null) {
                    WordPickerSection(viewModel = viewModel, wordList = selectedList, palette = palette)
                }
                CardCountSection(viewModel = viewModel, palette = palette)
                MatchModeSection(viewModel = viewModel, palette = palette)
                PlayersSection(viewModel = viewModel, palette = palette)
                ExtraOptionsSection(viewModel = viewModel, palette = palette)
                StartSection(viewModel = viewModel, palette = palette)
            }
        }
    }
}

@Composable
fun GameTitle() {
    val title = "Memory Game"
    val letterColors = listOf(
        Color(0xFFFFEB3B),
        Color(0xFFFF8A80),
        Color(0xFFB9F6CA),
        Color(0xFF80D8FF),
        Color(0xFFFF80AB),
        Color(0xFFE1BEE7)
    )
    val transition = rememberInfiniteTransition(label = "title")
    val wave = transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.2832f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "titleWave"
    )
    Row(verticalAlignment = Alignment.Bottom) {
        for (index in 0 until title.length) {
            val letter = title[index].toString()
            val offset = sin(wave.value + index * 0.55f) * 10f
            val color = letterColors[index % letterColors.size]
            Text(
                text = letter,
                fontSize = 40.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color,
                style = softTextShadow,
                modifier = Modifier.graphicsLayer {
                    translationY = offset
                }
            )
        }
    }
    Text(
        text = "Flip two cards. Find the pairs!",
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = Color.White,
        style = softTextShadow
    )
}

@Composable
fun SettingsSection(title: String, palette: ThemePalette, content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier
            .widthIn(max = 700.dp)
            .fillMaxWidth()
            .padding(bottom = 14.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.95f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = title,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = palette.accentDark
            )
            Spacer(modifier = Modifier.height(10.dp))
            content()
        }
    }
}

@Composable
fun OptionTile(
    title: String,
    subtitle: String,
    emoji: String,
    selected: Boolean,
    enabled: Boolean,
    palette: ThemePalette,
    modifier: Modifier,
    onClick: () -> Unit
) {
    var background = Color(0xFFF4F6FA)
    var borderColor = Color(0xFFDDE3EC)
    var titleColor = Color(0xFF263238)
    if (selected) {
        background = palette.accent.copy(alpha = 0.16f)
        borderColor = palette.accent
        titleColor = palette.accentDark
    }
    var tileAlpha = 1f
    if (!enabled) {
        tileAlpha = 0.35f
    }
    var targetScale = 1f
    if (selected) {
        targetScale = 1.04f
    }
    val scale = animateFloatAsState(targetValue = targetScale, animationSpec = tween(durationMillis = 200), label = "tileScale")
    Column(
        modifier = modifier
            .graphicsLayer {
                alpha = tileAlpha
                scaleX = scale.value
                scaleY = scale.value
            }
            .clip(RoundedCornerShape(18.dp))
            .background(background)
            .border(width = 3.dp, color = borderColor, shape = RoundedCornerShape(18.dp))
            .clickable(enabled = enabled) { onClick() }
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = emoji, fontSize = 26.sp)
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            color = titleColor,
            textAlign = TextAlign.Center,
            maxLines = 2
        )
        Text(
            text = subtitle,
            fontSize = 12.sp,
            color = Color(0xFF607D8B),
            textAlign = TextAlign.Center,
            maxLines = 2
        )
    }
}

@Composable
fun WordListSection(viewModel: GameViewModel, palette: ThemePalette) {
    val settings = viewModel.settings.value
    SettingsSection(title = "Choose a word list", palette = palette) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (wordList in viewModel.wordLists) {
                val isSelected = wordList.id == settings.wordListId
                OptionTile(
                    title = wordList.title,
                    subtitle = wordList.items.size.toString() + " words",
                    emoji = wordList.iconEmoji,
                    selected = isSelected,
                    enabled = true,
                    palette = palette,
                    modifier = Modifier.width(130.dp),
                    onClick = { viewModel.selectWordList(wordList.id) }
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WordPickerSection(viewModel: GameViewModel, wordList: WordList, palette: ThemePalette) {
    val settings = viewModel.settings.value
    val sectionTitle = "Pick the words (" + viewModel.selectedWordCount() + " of " + wordList.items.size + ")"
    SettingsSection(title = sectionTitle, palette = palette) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton(text = "Select all", background = palette.accent, textColor = Color.White, onClick = { viewModel.selectAllWords() })
            PillButton(text = "Clear", background = Color(0xFFECEFF1), textColor = Color(0xFF37474F), onClick = { viewModel.clearWords() })
        }
        Spacer(modifier = Modifier.height(12.dp))
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            for (item in wordList.items) {
                val isSelected = settings.selectedWordIds.contains(item.id)
                WordChip(item = item, selected = isSelected, palette = palette, onClick = { viewModel.toggleWord(item.id) })
            }
        }
    }
}

@Composable
fun WordChip(item: WordItem, selected: Boolean, palette: ThemePalette, onClick: () -> Unit) {
    var background = Color(0xFFF4F6FA)
    var borderColor = Color(0xFFDDE3EC)
    var textColor = Color(0xFF90A4AE)
    if (selected) {
        background = palette.accent.copy(alpha = 0.16f)
        borderColor = palette.accent
        textColor = palette.accentDark
    }
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .border(width = 2.dp, color = borderColor, shape = RoundedCornerShape(50))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (item.emoji.isNotEmpty()) {
            Text(text = item.emoji, fontSize = 18.sp)
            Spacer(modifier = Modifier.width(6.dp))
        }
        Text(text = item.word, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = textColor)
        if (selected) {
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "✓", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = palette.accent)
        }
    }
}

@Composable
fun CardCountSection(viewModel: GameViewModel, palette: ThemePalette) {
    val settings = viewModel.settings.value
    SettingsSection(title = "How many cards?", palette = palette) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            for (count in GameRules.cardCountOptions) {
                OptionTile(
                    title = count.toString(),
                    subtitle = GameRules.difficultyLabel(count),
                    emoji = GameRules.difficultyEmoji(count),
                    selected = settings.cardCount == count,
                    enabled = true,
                    palette = palette,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.setCardCount(count) }
                )
            }
        }
    }
}

@Composable
fun MatchModeSection(viewModel: GameViewModel, palette: ThemePalette) {
    val settings = viewModel.settings.value
    val modes = MatchMode.values()
    SettingsSection(title = "How do cards match?", palette = palette) {
        for (rowIndex in 0 until 2) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (columnIndex in 0 until 2) {
                    val modeIndex = rowIndex * 2 + columnIndex
                    if (modeIndex < modes.size) {
                        val mode = modes[modeIndex]
                        OptionTile(
                            title = mode.title,
                            subtitle = mode.subtitle,
                            emoji = mode.emoji,
                            selected = settings.matchMode == mode,
                            enabled = viewModel.isModeAvailable(mode),
                            palette = palette,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.setMatchMode(mode) }
                        )
                    }
                }
            }
        }
        if (!viewModel.isModeAvailable(MatchMode.PICTURES)) {
            Text(
                text = "This list has words only, so only the Words option works.",
                fontSize = 13.sp,
                color = Color(0xFF607D8B)
            )
        }
    }
}

@Composable
fun PlayersSection(viewModel: GameViewModel, palette: ThemePalette) {
    val settings = viewModel.settings.value
    SettingsSection(title = "Players", palette = palette) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OptionTile(
                title = "1 player",
                subtitle = "Beat your best moves",
                emoji = palette.playerOneMascotEmoji,
                selected = settings.playerCount == 1,
                enabled = true,
                palette = palette,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.setPlayerCount(1) }
            )
            OptionTile(
                title = "2 players",
                subtitle = "Take turns and race",
                emoji = palette.playerOneMascotEmoji + palette.playerTwoMascotEmoji,
                selected = settings.playerCount == 2,
                enabled = true,
                palette = palette,
                modifier = Modifier.weight(1f),
                onClick = { viewModel.setPlayerCount(2) }
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
            value = settings.playerOneName,
            onValueChange = { newName -> viewModel.setPlayerOneName(newName) },
            label = { Text(text = palette.playerOneMascotEmoji + " Player 1 name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        if (settings.playerCount == 2) {
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = settings.playerTwoName,
                onValueChange = { newName -> viewModel.setPlayerTwoName(newName) },
                label = { Text(text = palette.playerTwoMascotEmoji + " Player 2 name") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ExtraOptionsSection(viewModel: GameViewModel, palette: ThemePalette) {
    val settings = viewModel.settings.value
    val delaySeconds = settings.flipBackDelayMillis / 1000f
    SettingsSection(title = "Extra options", palette = palette) {
        Text(
            text = "⏳ Flip cards back after " + delaySeconds.toString() + " seconds",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF263238)
        )
        Slider(
            value = delaySeconds,
            onValueChange = { newValue -> viewModel.setFlipBackDelay(newValue) },
            valueRange = GameRules.MIN_DELAY_SECONDS..GameRules.MAX_DELAY_SECONDS,
            steps = 8,
            colors = SliderDefaults.colors(
                thumbColor = palette.accent,
                activeTrackColor = palette.accent
            )
        )
        SwitchRow(
            title = "🔢 Show numbers on cards",
            subtitle = "Helps when you play with students on a video call",
            checked = settings.showNumbers,
            palette = palette,
            onCheckedChange = { checked -> viewModel.setShowNumbers(checked) }
        )
    }
}

@Composable
fun SwitchRow(title: String, subtitle: String, checked: Boolean, palette: ThemePalette, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color(0xFF263238))
            Text(text = subtitle, fontSize = 12.sp, color = Color(0xFF607D8B))
        }
        Switch(
            checked = checked,
            onCheckedChange = { newValue -> onCheckedChange(newValue) },
            colors = SwitchDefaults.colors(checkedTrackColor = palette.accent)
        )
    }
}

@Composable
fun StartSection(viewModel: GameViewModel, palette: ThemePalette) {
    val canStart = viewModel.canStartGame()
    val transition = rememberInfiniteTransition(label = "startPulse")
    val pulse = transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700),
            repeatMode = RepeatMode.Reverse
        ),
        label = "startPulseScale"
    )
    var buttonScale = 1f
    var buttonBrush = Brush.horizontalGradient(colors = listOf(Color(0xFFB0BEC5), Color(0xFF90A4AE)))
    if (canStart) {
        buttonScale = pulse.value
        buttonBrush = Brush.horizontalGradient(colors = listOf(Color(0xFFFFA726), Color(0xFFFF4081)))
    }
    Box(
        modifier = Modifier
            .widthIn(max = 700.dp)
            .fillMaxWidth()
            .padding(top = 6.dp)
            .graphicsLayer {
                scaleX = buttonScale
                scaleY = buttonScale
            }
            .clip(RoundedCornerShape(28.dp))
            .background(buttonBrush)
            .clickable(enabled = canStart) { viewModel.startGame() }
            .padding(vertical = 18.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "▶  Start the game",
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White,
            style = softTextShadow
        )
    }
    if (!canStart) {
        Spacer(modifier = Modifier.height(10.dp))
        val message = "Pick at least " + viewModel.requiredWordCount() + " words for " +
                viewModel.settings.value.cardCount + " cards. You picked " + viewModel.selectedWordCount() + "."
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xCC263238))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(text = message, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
    }
}
